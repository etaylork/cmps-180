SELECT p.Name, p.SSN
FROM persons p
WHERE Salary > 20000;

