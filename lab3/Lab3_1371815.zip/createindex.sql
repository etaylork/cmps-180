CREATE INDEX ON Persons(HouseID,ApartmentNumber);
